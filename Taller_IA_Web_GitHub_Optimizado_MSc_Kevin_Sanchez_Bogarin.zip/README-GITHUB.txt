TALLER IA — VERSIÓN OPTIMIZADA PARA GITHUB PAGES

SUBIDA RECOMENDADA
1. Descomprima este ZIP.
2. Suba TODO el contenido de esta carpeta a la raíz del repositorio:
   - index.html
   - css/
   - js/
   - assets/
   - .nojekyll
3. No suba solamente el ZIP.
4. En GitHub: Settings > Pages.
5. Source: Deploy from a branch.
6. Branch: main / (root).
7. Guarde y espere la publicación.

IMPORTANTE
- index.html debe quedar en la raíz del repositorio.
- Las carpetas css, js y assets deben conservar exactamente sus nombres.
- Los videos de YouTube requieren conexión a Internet.
- El resto del sitio es estático y no requiere backend.

OPTIMIZACIÓN
- Las imágenes fueron convertidas de PNG pesados a WebP.
- El HTML permanece liviano y usa rutas relativas compatibles con GitHub Pages.
