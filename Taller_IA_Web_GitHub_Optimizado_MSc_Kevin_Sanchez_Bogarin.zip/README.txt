TALLER IA — SITIO WEB INTERACTIVO
MSc Kevin Sánchez Bogarín

Cómo abrir:
1. Descomprima la carpeta completa.
2. Abra index.html con Chrome, Edge, Safari o Firefox.
3. No requiere instalación ni servidor.
4. Los videos de YouTube sí requieren conexión a Internet.

Características:
- 19 escenas/estaciones con navegación y progreso.
- Modo exposición.
- Diagnóstico de experiencia con IA.
- Transformaciones de entrada/salida.
- Comparación y constructor de prompts.
- Dos videos integrados + enlace directo a YouTube.
- Ciberseguridad: privacidad/datos, phishing, contraseñas, Wi-Fi y huella digital.
- Simulador fotocopia -> recurso -> HTML.
- Comparador PDF -> infografía básica/moderna/inmersiva.
- Actividad de detectar errores.
- Simulación de NotebookLM basada en una fuente.
- Generador de reto + temporizador.
- Ticket de salida.
- Guardado local mediante localStorage. No envía datos a ningún servidor.
- Guía de ciberseguridad incluida en assets/docs/.

Fuente de ciberseguridad:
Guía de Apoyo para la prevención del ciberdelito para educadores, padres y madres de familia (MEP–UNODC), incluida localmente.
